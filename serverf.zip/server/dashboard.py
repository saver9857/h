import streamlit as st
import requests
import pandas as pd
import plotly.graph_objects as go
import time
from datetime import datetime

API_URL = "http://127.0.0.1:8000"

st.set_page_config(layout="wide", page_title="Real-Time Sensor Dashboard")

# Custom CSS
st.markdown("""
<style>
    .header {
        font-size: 3em;
        font-weight: bold;
        color: #4CAF50;
        text-align: center;
        padding: 10px;
    }
    .subheader {
        font-size: 1.5em;
        color: #757575;
        text-align: center;
        margin-bottom: 20px;
    }
    .metric-container {
        padding: 15px;
        border-radius: 10px;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        text-align: center;
        margin: 10px;
        background: linear-gradient(145deg, #f0f2f6, #e6e9ef);
    }
    .metric-value {
        font-size: 2.5em;
        font-weight: bold;
        margin: 10px 0;
    }
    .metric-label {
        font-size: 1.2em;
        color: #555;
    }
    .status-indicator {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        margin-right: 8px;
    }
    .status-online {
        background-color: #4CAF50;
    }
    .status-offline {
        background-color: #F44336;
    }
    .data-table {
        background-color: #f9f9f9;
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
    }
    .error-container {
        padding: 20px;
        border-radius: 10px;
        background-color: #ffebee;
        border-left: 5px solid #f44336;
        margin: 20px 0;
        color: #d32f2f;
    }
    .warning-container {
        padding: 20px;
        border-radius: 10px;
        background-color: #fff8e1;
        border-left: 5px solid #ffc107;
        margin: 20px 0;
    }
    .success-container {
        padding: 20px;
        border-radius: 10px;
        background-color: #e8f5e9;
        border-left: 5px solid #4caf50;
        margin: 20px 0;
    }
    .info-container {
        padding: 20px;
        border-radius: 10px;
        background-color: #e3f2fd;
        border-left: 5px solid #2196f3;
        margin: 20px 0;
    }
    .reconnect-button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
        font-size: 16px;
        margin: 10px 0;
    }
    .reconnect-button:hover {
        background-color: #45a049;
    }
    .port-list {
        background-color: #f5f5f5;
        padding: 10px;
        border-radius: 5px;
        margin: 10px 0;
        font-family: monospace;
    }
</style>
""", unsafe_allow_html=True)

# Header
st.markdown('<p class="header">🌱 Real-Time IoT Sensor Dashboard</p>', unsafe_allow_html=True)
st.markdown('<p class="subheader">Live updates from your environment</p>', unsafe_allow_html=True)

# Check API status
try:
    status_response = requests.get(f"{API_URL}/", timeout=5)
    if status_response.status_code == 200:
        status_data = status_response.json()
        if status_data.get("arduino_connected"):
            status_indicator = "status-online"
            status_text = "LIVE DATA"
        else:
            status_indicator = "status-offline"
            status_text = "DISCONNECTED"
        st.markdown(
            f'<p><span class="status-indicator {status_indicator}"></span>System Status: {status_text}</p>',
            unsafe_allow_html=True
        )
    else:
        st.error("❌ API not responding properly")
        st.stop()
except requests.exceptions.RequestException:
    st.markdown("""
    <div class="error-container">
        <h3>❌ Cannot Connect to Sensor System</h3>
        <p>Please ensure the following:</p>
        <ul>
            <li>The sensor server is running (python server.py)</li>
            <li>Arduino is properly connected to your computer</li>
            <li>USB cable is securely plugged in</li>
            <li>Correct serial port is configured</li>
        </ul>
        <p><b>Troubleshooting:</b> Check server logs for connection details</p>
    </div>
    """, unsafe_allow_html=True)
    st.stop()

# Add port information if Arduino is disconnected
if not status_data.get("arduino_connected"):
    try:
        ports_response = requests.get(f"{API_URL}/ports", timeout=5)
        if ports_response.status_code == 200:
            ports_data = ports_response.json()
            available_ports = ports_data.get("available_ports", [])
            configured_ports = ports_data.get("configured_ports", [])
            
            st.markdown("""
            <div class="info-container">
                <h3>📡 Serial Port Information</h3>
                <p><b>Configured Ports:</b></p>
                <div class="port-list">{}</div>
                <p><b>Available Ports:</b></p>
                <div class="port-list">{}</div>
            </div>
            """.format(", ".join(configured_ports), ", ".join(available_ports) if available_ports else "None"), unsafe_allow_html=True)
    except:
        pass

# Add reconnect button if Arduino is disconnected
if not status_data.get("arduino_connected"):
    if st.button("🔄 Attempt to Reconnect to Arduino"):
        try:
            reconnect_response = requests.get(f"{API_URL}/reconnect", timeout=5)
            if reconnect_response.status_code == 200:
                reconnect_data = reconnect_response.json()
                if reconnect_data.get("success"):
                    st.markdown("""
                    <div class="success-container">
                        <h3>✅ Reconnection Successful</h3>
                        <p>Successfully connected to Arduino. Refreshing dashboard...</p>
                    </div>
                    """, unsafe_allow_html=True)
                    st.rerun()
                else:
                    st.error("❌ Reconnection failed. Please check your Arduino connection.")
            else:
                st.error("❌ Failed to send reconnection request.")
        except requests.exceptions.RequestException:
            st.error("❌ Could not connect to server for reconnection.")
    
    st.markdown("""
    <div class="warning-container">
        <h3>⚠️ Arduino Not Connected</h3>
        <p>The system is running but not receiving data from Arduino.</p>
        <p><b>Common solutions:</b></p>
        <ul>
            <li><b>Close Arduino IDE's Serial Monitor</b> - This is the most common cause of "Device or resource busy"</li>
            <li>Close any other terminal programs using the serial port</li>
            <li>Unplug and replug the Arduino USB cable</li>
            <li>Check if the correct port is configured in server.py</li>
            <li>Try: sudo chmod 666 /dev/ttyACM0 (if permission denied)</li>
        </ul>
        <p>Try the reconnect button above after applying these solutions.</p>
    </div>
    """, unsafe_allow_html=True)

# Refresh controls
col1, col2 = st.columns([3, 1])
with col1:
    refresh_interval = st.slider("Auto-refresh interval (seconds)", 1, 30, 5)
with col2:
    if st.button("Refresh Now"):
        st.rerun()

# Function to fetch data
@st.cache_data(ttl=5)
def fetch_data(endpoint="/data"):
    try:
        response = requests.get(f"{API_URL}{endpoint}", timeout=5)
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 404:
            return None
        else:
            st.error(f"API Error: {response.status_code}")
            return None
    except requests.exceptions.RequestException as e:
        st.error(f"Connection Error: {e}")
        return None

# Fetch data
data = fetch_data()

if data is None:
    if status_data.get("arduino_connected"):
        st.markdown("""
        <div class="warning-container">
            <h3>⚠️ No Sensor Data Available</h3>
            <p>Arduino is connected but no data has been received yet.</p>
            <p>This could mean:</p>
            <ul>
                <li>Sensors are not initialized</li>
                <li>Arduino is not sending data in expected format</li>
                <li>Communication issue between Arduino and sensors</li>
            </ul>
            <p>Please check your Arduino code and sensor connections.</p>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="warning-container">
            <h3>⚠️ No Sensor Data Available</h3>
            <p>Arduino is not connected to the server.</p>
            <p>Connect your Arduino and try the reconnect button above.</p>
        </div>
        """, unsafe_allow_html=True)
    st.stop()

if not data:
    st.warning("⚠️ No sensor data available yet. Waiting for first reading...")
    st.stop()

# Convert to DataFrame
df = pd.DataFrame(data)
df["timestamp"] = pd.to_datetime(df["timestamp"])

# Get latest values
latest_values = df.iloc[-1]

# Display current values with custom styling
col1, col2, col3, col4 = st.columns(4)
with col1:
    st.markdown("""
    <div class="metric-container">
        <div class="metric-label">🌡️ Temperature</div>
        <div class="metric-value">{:.1f} °C</div>
    </div>
    """.format(latest_values['temperature']), unsafe_allow_html=True)
    
with col2:
    st.markdown("""
    <div class="metric-container">
        <div class="metric-label">💧 Humidity</div>
        <div class="metric-value">{:.1f} %</div>
    </div>
    """.format(latest_values['humidity']), unsafe_allow_html=True)
    
with col3:
    st.markdown("""
    <div class="metric-container">
        <div class="metric-label">🌱 Soil Moisture</div>
        <div class="metric-value">{}</div>
    </div>
    """.format(latest_values['moisture']), unsafe_allow_html=True)
    
with col4:
    st.markdown("""
    <div class="metric-container">
        <div class="metric-label">📏 Distance</div>
        <div class="metric-value">{:.1f} cm</div>
    </div>
    """.format(latest_values['distance']), unsafe_allow_html=True)

st.markdown("---")

# Show last 20 data points
df_recent = df.tail(20)

# Create plots
col_plot1, col_plot2 = st.columns(2)

with col_plot1:
    # Temperature plot
    fig_temp = go.Figure()
    fig_temp.add_trace(go.Scatter(
        x=df_recent["timestamp"], 
        y=df_recent["temperature"], 
        mode="lines+markers",
        line=dict(color="#FF6B6B", width=3),
        marker=dict(size=8)
    ))
    fig_temp.update_layout(
        title="🌡️ Temperature", 
        height=300,
        xaxis_title="Time",
        yaxis_title="°C",
        margin=dict(l=20, r=20, b=20, t=40)
    )
    st.plotly_chart(fig_temp, use_container_width=True)
    
    # Moisture plot
    fig_moisture = go.Figure()
    fig_moisture.add_trace(go.Scatter(
        x=df_recent["timestamp"], 
        y=df_recent["moisture"], 
        mode="lines+markers",
        line=dict(color="#4ECDC4", width=3),
        marker=dict(size=8)
    ))
    fig_moisture.update_layout(
        title="🌱 Soil Moisture", 
        height=300,
        xaxis_title="Time",
        yaxis_title="Analog Value",
        margin=dict(l=20, r=20, b=20, t=40)
    )
    st.plotly_chart(fig_moisture, use_container_width=True)

with col_plot2:
    # Humidity plot
    fig_hum = go.Figure()
    fig_hum.add_trace(go.Scatter(
        x=df_recent["timestamp"], 
        y=df_recent["humidity"], 
        mode="lines+markers",
        line=dict(color="#45B7D1", width=3),
        marker=dict(size=8)
    ))
    fig_hum.update_layout(
        title="💧 Humidity", 
        height=300,
        xaxis_title="Time",
        yaxis_title="%",
        margin=dict(l=20, r=20, b=20, t=40)
    )
    st.plotly_chart(fig_hum, use_container_width=True)
    
    # Distance plot
    fig_distance = go.Figure()
    fig_distance.add_trace(go.Scatter(
        x=df_recent["timestamp"], 
        y=df_recent["distance"], 
        mode="lines+markers",
        line=dict(color="#F7B731", width=3),
        marker=dict(size=8)
    ))
    fig_distance.update_layout(
        title="📏 Distance", 
        height=300,
        xaxis_title="Time",
        yaxis_title="cm",
        margin=dict(l=20, r=20, b=20, t=40)
    )
    st.plotly_chart(fig_distance, use_container_width=True)

# Show recent data with custom styling
st.subheader("📋 Recent Sensor Data")
recent_display = df.tail(5).copy()
recent_display['timestamp'] = recent_display['timestamp'].dt.strftime('%Y-%m-%d %H:%M:%S')

st.markdown("""
<div class="data-table">
""", unsafe_allow_html=True)

st.dataframe(
    recent_display,
    column_config={
        "id": "ID",
        "timestamp": "Timestamp",
        "temperature": "Temperature (°C)",
        "humidity": "Humidity (%)",
        "moisture": "Soil Moisture",
        "distance": "Distance (cm)"
    },
    use_container_width=True,
    hide_index=True
)

st.markdown("</div>", unsafe_allow_html=True)

# Display last update time
st.caption(f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

# Auto-refresh
time.sleep(refresh_interval)
st.rerun()