# import serial
# import time

# # Change to the correct port
# port = "/dev/ttyACM0"  # Adjust as necessary
# baud_rate = 9600

# ser = None  # Initialize ser

# try:
#     ser = serial.Serial(port, baud_rate, timeout=1)
#     print(f"Connected to {port}")

#     while True:
#         line = ser.readline().decode().strip()
#         if line:
#             print(f"Received: {line}")
# except serial.SerialException as e:
#     print(f"Could not open {port}: {e}")
# except KeyboardInterrupt:
#     print("Stopping...")
# finally:
#     if ser and ser.is_open:
#         ser.close()
#         print(f"Closed connection to {port}")


import streamlit as st
import requests

st.title("Sensor Data Dashboard")

# Fetch data from FastAPI
try:
    response = requests.get("http://127.0.0.1:8000/data")
    if response.status_code == 200:
        data = response.json()
        st.write(data)
    else:
        st.error(f"Error: {response.status_code}")
except requests.ConnectionError:
    st.error("Failed to connect to the FastAPI server. Please make sure it is running.")
