# 🌱 Real-Time Sensor Monitoring System

A comprehensive IoT sensor monitoring system that collects data from Arduino sensors (temperature, humidity, soil moisture, and distance) via serial communication, stores it in SQLite database, and displays real-time visualizations through a web dashboard.

## 📋 Table of Contents

- [Project Overview](#project-overview)
- [Features](#features)
- [System Architecture](#system-architecture)
- [Project Structure](#project-structure)
- [Hardware Requirements](#hardware-requirements)
- [Software Requirements](#software-requirements)
- [Installation & Setup](#installation--setup)
- [Running the Project](#running-the-project)
- [API Endpoints](#api-endpoints)
- [Troubleshooting](#troubleshooting)
- [Contributing](#contributing)

## 🔍 Project Overview

This project creates a complete sensor monitoring pipeline that:

1. **Collects** sensor data from Arduino via serial communication
2. **Processes** and parses the incoming data using regex patterns
3. **Stores** data in SQLite database with timestamps
4. **Serves** data through FastAPI REST endpoints
5. **Visualizes** real-time data through Streamlit dashboard

## ✨ Features

- **Real-time Data Collection**: Continuous monitoring from Arduino sensors
- **Multi-sensor Support**: Temperature, humidity, soil moisture, and distance sensors
- **RESTful API**: FastAPI backend with JSON endpoints
- **Interactive Dashboard**: Live-updating charts and graphs
- **Data Persistence**: SQLite database for historical data storage
- **Error Handling**: Robust error handling and logging
- **Configurable Refresh**: Adjustable dashboard refresh intervals

## 🏗️ System Architecture

```
Arduino Sensors → Serial Port → Python Server → SQLite DB → FastAPI → Streamlit Dashboard
                                      ↓
                                Background Thread
```

## 📁 Project Structure

```
server/
├── server.py           # FastAPI backend server with serial communication
├── dashboard.py        # Streamlit dashboard for data visualization
├── port.py            # Serial port testing utility (optional)
├── sensor_data.db     # SQLite database (auto-generated)
├── requirements.txt   # Python dependencies
├── README.md          # Project documentation
└── __pycache__/       # Python cache files
```

### File Descriptions

- **`server.py`**: Main backend application that handles:
  - Serial communication with Arduino
  - Data parsing using regex
  - SQLite database operations
  - FastAPI endpoints for data retrieval
  - Background threading for continuous data collection

- **`dashboard.py`**: Streamlit web application featuring:
  - Real-time sensor data visualization
  - Interactive plots for each sensor type
  - Configurable refresh intervals
  - Live data filtering (last 60 seconds)

- **`port.py`**: Development utility for testing serial connections
- **`sensor_data.db`**: SQLite database storing all sensor readings with timestamps

## 🔧 Hardware Requirements

### Arduino Setup
- **Arduino Uno/Nano** or compatible board
- **DHT22** temperature and humidity sensor
- **Soil moisture sensor** (analog)
- **HC-SR04** ultrasonic distance sensor
- **USB cable** for serial communication
- **Breadboard and jumper wires**

### Expected Arduino Output Format
The Arduino should send data in this format:
```
---
Analog Output: 1006
Status: Soil is too dry - time to water!
Temperature: 26.20°C, Humidity: 81.00%
Distance: 35.72 cm
--------------------
```

## 💻 Software Requirements

### System Requirements
- **Operating System**: Linux (tested on Ubuntu/Debian)
- **Python**: 3.8 or higher
- **Serial Port**: `/dev/ttyACM0` (or adjust in code)

### Python Dependencies
See `requirements.txt` for complete list:
- `fastapi` - Web framework for API
- `uvicorn` - ASGI server
- `streamlit` - Dashboard framework
- `plotly` - Interactive plotting
- `pandas` - Data manipulation
- `pyserial` - Serial communication
- `requests` - HTTP client
- `sqlite3` - Database (built-in)

## 🚀 Installation & Setup

### 1. Clone/Download Project
```bash
# Navigate to your project directory
cd /path/to/your/project/server
```

### 2. Create Virtual Environment (Recommended)
```bash
# Create virtual environment
python3 -m venv sensor_env

# Activate virtual environment
source sensor_env/bin/activate  # On Linux/Mac
# or
sensor_env\Scripts\activate     # On Windows
```

### 3. Install Dependencies
```bash
# Install all required packages
pip install -r requirements.txt
```

### 4. Hardware Setup
1. Connect your Arduino sensors according to your circuit design
2. Upload the Arduino sketch that outputs data in the expected format
3. Connect Arduino to your computer via USB
4. Note the serial port (usually `/dev/ttyACM0` on Linux)

### 5. Verify Serial Connection
```bash
# Check available serial ports
ls /dev/tty*

# Test serial connection (optional)
python port.py
```

## 🏃‍♂️ Running the Project

### Method 1: Two Terminal Approach (Recommended)

**Terminal 1: Start FastAPI Server**
```bash
# Navigate to project directory
cd /path/to/your/project/server

# Activate virtual environment (if using)
source sensor_env/bin/activate

# Start FastAPI server
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

You should see:
```
INFO:     Uvicorn running on http://0.0.0.0:8001 (Press CTRL+C to quit)
Connected to /dev/ttyACM0
Received from Serial: Temperature: 26.20°C, Humidity: 81.00%
✅ Data successfully inserted into SQLite!
```

**Terminal 2: Start Streamlit Dashboard**
```bash
# Open new terminal and navigate to project directory
cd /path/to/your/project/server

# Activate virtual environment (if using)
source sensor_env/bin/activate

# Start Streamlit dashboard
streamlit run dashboard.py
```

The dashboard will open in your browser at `http://localhost:8501`

### Method 2: Background Process
```bash
# Start FastAPI in background
uvicorn server:app --host 0.0.0.0 --port 8001 &

# Start Streamlit dashboard
streamlit run dashboard.py
```

## 🌐 API Endpoints

### Base URL: `http://127.0.0.1:8001`

#### Get Latest Sensor Reading
```http
GET /latest
```

**Response:**
```json
{
    "id": 1378,
    "timestamp": "2025-02-22 15:36:50",
    "temperature": 26.7,
    "humidity": 81.0,
    "moisture": 1006,
    "distance": 36.43
}
```

#### Get All Sensor Data
```http
GET /data
```

**Response:**
```json
[
    {
        "id": 1377,
        "timestamp": "2025-02-22 15:36:48",
        "temperature": 26.7,
        "humidity": 81.0,
        "moisture": 1006,
        "distance": 11.28
    },
    {
        "id": 1378,
        "timestamp": "2025-02-22 15:36:50",
        "temperature": 26.7,
        "humidity": 81.0,
        "moisture": 1006,
        "distance": 36.43
    }
]
```

## 🛠️ Troubleshooting

### Common Issues

#### 1. Serial Port Connection Failed
```
Error: Could not open /dev/ttyACM0
```
**Solutions:**
- Check if Arduino is connected: `ls /dev/tty*`
- Try different port: `/dev/ttyUSB0`, `/dev/ttyACM1`
- Check permissions: `sudo chmod 666 /dev/ttyACM0`
- Add user to dialout group: `sudo usermod -a -G dialout $USER`

#### 2. FastAPI Connection Refused
```
ConnectionError: Failed to establish connection [Errno 111] Connection refused
```
**Solutions:**
- Ensure FastAPI server is running on port 8001
- Check if port is available: `netstat -tulpn | grep 8001`
- Verify API URL in dashboard.py: `http://127.0.0.1:8001/data`

#### 3. No Data in Dashboard
**Check these steps:**
1. Verify FastAPI server shows "Data successfully inserted"
2. Check database has data: `sqlite3 sensor_data.db "SELECT COUNT(*) FROM sensor_data;"`
3. Test API manually: `curl http://127.0.0.1:8001/data`
4. Ensure Streamlit is refreshing (check slider value)

#### 4. Database Issues
```bash
# Check database contents
sqlite3 sensor_data.db "SELECT * FROM sensor_data ORDER BY timestamp DESC LIMIT 5;"

# Reset database (if needed)
rm sensor_data.db
# Restart server to recreate table
```

#### 5. Import Errors
```bash
# Reinstall packages
pip install --upgrade -r requirements.txt

# Check Python version
python --version  # Should be 3.8+
```

### Debugging Tips

1. **Check Serial Output**: Monitor what Arduino is sending
   ```python
   # Add to server.py for debugging
   print(f"Raw serial line: {repr(line)}")
   ```

2. **Test API Endpoints**: Use curl or browser
   ```bash
   curl -X GET http://127.0.0.1:8001/data | jq
   ```

3. **Monitor Logs**: Check terminal outputs for errors

4. **Database Inspection**: 
   ```bash
   sqlite3 sensor_data.db
   .tables
   .schema sensor_data
   SELECT * FROM sensor_data LIMIT 5;
   .quit
   ```

## 🔄 Auto-refresh Dashboard

To make the dashboard auto-refresh without manual intervention, you can:

1. **Use built-in refresh**: The current implementation uses a while loop with `time.sleep()`
2. **Add auto-refresh component**: Install `streamlit-autorefresh`
   ```bash
   pip install streamlit-autorefresh
   ```

## 📊 Data Schema

### SQLite Table: `sensor_data`
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key (auto-increment) |
| timestamp | DATETIME | Data collection time |
| temperature | REAL | Temperature in Celsius |
| humidity | REAL | Humidity percentage |
| moisture | INTEGER | Soil moisture analog value |
| distance | REAL | Distance in centimeters |

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📝 License

This project is open source and available under the [MIT License](LICENSE).

## 🆘 Support

If you encounter issues:
1. Check the troubleshooting section
2. Review terminal outputs for error messages
3. Ensure all dependencies are installed correctly
4. Verify hardware connections

---

**Happy Monitoring! 🌱📊**
