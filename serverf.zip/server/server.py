import threading
import serial
import re
import sqlite3
import time
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import os
import glob

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize serial connection
serial_ports = ["/dev/ttyACM0", "/dev/ttyUSB0", "/dev/ttyACM1"]
ser = None
connection_lock = threading.Lock()

def get_available_serial_ports():
    """List all available serial ports"""
    if os.name == 'nt':  # Windows
        ports = ['COM%s' % (i + 1) for i in range(256)]
    else:  # Unix-like
        ports = glob.glob('/dev/tty[A-Za-z]*')
    
    available_ports = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            available_ports.append(port)
        except (OSError, serial.SerialException):
            pass
    return available_ports

def connect_to_arduino():
    global ser
    with connection_lock:
        if ser is not None and ser.is_open:
            return True
            
        # First, check what ports are actually available
        available_ports = get_available_serial_ports()
        print(f"Available serial ports: {available_ports}")
        
        for port in serial_ports:
            try:
                # Try to close the port if it's already open by another process
                if port in available_ports:
                    print(f"Attempting to connect to {port}...")
                    ser = serial.Serial(port, 9600, timeout=1)
                    print(f"✅ Connected to Arduino on {port}")
                    return True
                else:
                    print(f"⚠️ Port {port} not available")
            except serial.SerialException as e:
                if "busy" in str(e).lower():
                    print(f"❌ Port {port} is busy. Another process might be using it.")
                    print("   Possible solutions:")
                    print("   1. Close Arduino IDE's Serial Monitor")
                    print("   2. Close any other terminal programs using the port")
                    print("   3. Unplug and replug the Arduino")
                    print("   4. Wait a few seconds and try again")
                else:
                    print(f"❌ Could not open {port}: {e}")
            except PermissionError as e:
                print(f"❌ Permission denied for {port}: {e}")
                print("   Try: sudo chmod 666 /dev/ttyACM0")
                print("   Or add user to dialout group: sudo usermod -a -G dialout $USER")
        
        print("⚠️  No Arduino found. Will retry in 30 seconds...")
        return False

# Initial connection attempt
connect_to_arduino()

# Connect to SQLite
conn = sqlite3.connect("sensor_data.db", check_same_thread=False)
cursor = conn.cursor()

# Create table if it doesn't exist //Schema,Table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS sensor_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        temperature REAL,
        humidity REAL,
        moisture INTEGER,
        distance REAL
    )
""")
conn.commit()

# Function to read and parse serial data
def read_from_serial():
    global ser
    with connection_lock:
        if ser is None or not ser.is_open:
            print("⚠️  No serial connection available. Attempting to reconnect...")
            if not connect_to_arduino():
                return
        
    try:
        lines = []
        while True:
            line = ser.readline().decode().strip()
            if line == "--------------------":
                break
            lines.append(line)
        
        temperature, humidity, moisture, distance = None, None, None, None
        
        for line in lines:
            print(f"Received from Serial: {line}")
            temp_match = re.search(r"Temperature:\s*([\d.]+)", line)
            hum_match = re.search(r"Humidity:\s*([\d.]+)", line)
            moisture_match = re.search(r"Analog Output:\s*(\d+)", line)
            distance_match = re.search(r"Distance:\s*([\d.]+)", line)
            
            if temp_match:
                temperature = float(temp_match.group(1))
            if hum_match:
                humidity = float(hum_match.group(1))
            if moisture_match:
                moisture = int(moisture_match.group(1))
            if distance_match:
                distance = float(distance_match.group(1))
        
        print(f"Parsed Data -> Temperature: {temperature}, Humidity: {humidity}, Moisture: {moisture}, Distance: {distance}")
        
        # Only insert if we have valid sensor data
        if temperature is not None and humidity is not None and moisture is not None and distance is not None:
            cursor.execute(
                "INSERT INTO sensor_data (temperature, humidity, moisture, distance) VALUES (?, ?, ?, ?)",
                (temperature, humidity, moisture, distance)
            )
            conn.commit()
            print("✅ Real sensor data successfully inserted into SQLite!")
        else:
            print("⚠️  Incomplete data received. Skipping insertion.")
    except Exception as e:
        print(f"Error in read_from_serial: {e}")
        with connection_lock:
            if ser and ser.is_open:
                ser.close()
            ser = None

# Background thread for continuous data reading
def continuous_read():
    while True:
        read_from_serial()
        time.sleep(2)

@app.on_event("startup")
def start_background_thread():
    thread = threading.Thread(target=continuous_read, daemon=True)
    thread.start()
    print("🚀 Background data collection started!")

# Function to check connection status
def get_connection_status():
    with connection_lock:
        return ser is not None and ser.is_open

# API endpoints
@app.get("/latest")
def get_latest_data():
    cursor.execute("SELECT * FROM sensor_data ORDER BY timestamp DESC LIMIT 1")
    row = cursor.fetchone()
    if row:
        return {
            "id": row[0],
            "timestamp": row[1],
            "temperature": row[2],
            "humidity": row[3],
            "moisture": row[4],
            "distance": row[5]
        }
    raise HTTPException(status_code=404, detail="No sensor data available")

@app.get("/data")
def get_all_data():
    cursor.execute("SELECT * FROM sensor_data ORDER BY timestamp ASC")
    rows = cursor.fetchall()
    if not rows:
        raise HTTPException(status_code=404, detail="No sensor data available")
    
    return [
        {"id": row[0], "timestamp": row[1], "temperature": row[2], "humidity": row[3], "moisture": row[4], "distance": row[5]}
        for row in rows
    ]

@app.get("/data/recent/{limit}")
def get_recent_data(limit: int = 20):
    cursor.execute("SELECT * FROM sensor_data ORDER BY timestamp DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    if not rows:
        raise HTTPException(status_code=404, detail="No sensor data available")
    
    return [
        {"id": row[0], "timestamp": row[1], "temperature": row[2], "humidity": row[3], "moisture": row[4], "distance": row[5]}
        for row in rows
    ]

@app.get("/reconnect")
def force_reconnect():
    global ser
    with connection_lock:
        if ser and ser.is_open:
            ser.close()
        ser = None
    success = connect_to_arduino()
    return {
        "success": success,
        "arduino_connected": success,
        "message": "Reconnection successful" if success else "Reconnection failed"
    }

@app.get("/ports")
def list_ports():
    """List all available serial ports"""
    available_ports = get_available_serial_ports()
    return {
        "available_ports": available_ports,
        "configured_ports": serial_ports
    }

@app.get("/")
def health_check():
    return {
        "status": "running",
        "arduino_connected": get_connection_status(),
        "mode": "live_data" if get_connection_status() else "disconnected",
        "database": "sensor_data.db"
    }